BEKHTI

abderahman.bekhti

abderahman.bekhti@edu.univ-eiffel.fr

le seul vrai problème a été de comprendre le principe de colonne et de ligne, je pensais au depart que il fallait faire des colonnes et des lignes et que
celle ci representais déjà un élément et j'oubliais souvent la box qui allait avec.
Sans oublier aussi les dimensions que j'ai aussi eu du mal à comprendre.