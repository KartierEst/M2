package fr.uge.poo.paint.ex9;

public interface CanvaFactory {
    Canva withData(int x, int y);
}
