package fr.uge.poo.paint.ex3;

import java.awt.*;

public interface Shape {
    void draw(Graphics2D graphics);
}