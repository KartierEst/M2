package fr.uge.poo.ducks;

public interface Duck {

    String quack();

}
