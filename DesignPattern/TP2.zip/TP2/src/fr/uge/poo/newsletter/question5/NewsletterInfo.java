package fr.uge.poo.newsletter.question5;

public record NewsletterInfo(String name) {
}
