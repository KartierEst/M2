package fr.uge.poo.uberclient.question6;

import java.util.List;

public interface ScoreStrategy {
    public double computeScore(List<Integer> grades);
}
