package fr.uge.poo.uberclient.question6;

import java.util.List;

public record UberClientInfo(String firstname, String lastname, double averageGrade, List<String> emails){
    UberClientInfo(String firstname, String lastname){
        this(firstname,lastname,-1,null);
    }
}
