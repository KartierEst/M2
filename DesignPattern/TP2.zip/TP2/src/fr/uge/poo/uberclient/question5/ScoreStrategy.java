package fr.uge.poo.uberclient.question5;

import java.util.List;

public interface ScoreStrategy {
    public double computeScore(List<Integer> grades);
}
