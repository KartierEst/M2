package com.evilcorp.weatherservice;

public interface WeatherService {
    int query(String city);
}
